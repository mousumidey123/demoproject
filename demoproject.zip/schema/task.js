var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var Taskschema = new Schema({
    _id: { type: String, required: true },    
    name: { type: String, required: false, default: ""},
    msg: { type: String, required: false, default: ""},
    category:[
        {type: Schema.Types.ObjectId, ref: 'Categories'}
      ]
}, {
    timestamps: true
});
module.exports = mongoose.model('Task', Taskschema);