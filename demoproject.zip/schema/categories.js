var mongoose = require('mongoose');
var bcrypt = require('bcrypt');
var Schema = mongoose.Schema;
var Categoriesschema = new Schema({
    _id: { type: String, required: true },    
    title: { type: String, required: false, default: ""}
}, {
    timestamps: true
});
module.exports = mongoose.model('Categories', Categoriesschema);