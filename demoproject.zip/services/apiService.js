'use strict';
var express = require("express");
var Request = require("request");
var async = require("async");
var mongo = require('mongodb');
var ObjectID = mongo.ObjectID;


//======================MODELS============================

var TaskModels = require('../models/task');
var CategoryModels = require('../models/categories');


var apiService = {
    //User register
    createtask: (data, callback) => {
            data._id = new ObjectID;
            TaskModels.createtask(data, function (result) {
                console.log('resultresultresultresultresult',result);
                callback(result);
            })
    },

    createcategory: (data, callback) => {
        data._id = new ObjectID;
        CategoryModels.createcategory(data, function (result) {
            console.log('resultresultresultresultresult',result);
            callback(result);
        })
},

    
     // get all categories
     getAllCategories: (data, callback) => {
        TaskModels.gettask(data, function (result) {
                callback(result);
            });
    },

}

module.exports = apiService;