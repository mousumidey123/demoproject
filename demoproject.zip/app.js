var express = require('express');
var mongoose = require('mongoose');
var bodyparser = require('body-parser');

var app = express();

//===========================CORS support==============================
app.use(function (req, res, next) {
    req.setEncoding('utf8');
    // Website you wish to allow to connect
    res.setHeader("Access-Control-Allow-Origin", "*");

    // Request methods you wish to allow
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");

    // Request headers you wish to allow
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, x-access-token, user_id, authtoken");
    
    if ('OPTIONS' == req.method) {
        res.sendStatus(200);
    } else {
        next();
    }
});

//=========================Load the routes===============================

var apiRoutes = require('./routes/apiRoutes.js')(app, express);
app.use('/api', apiRoutes);

//===========================Connect to MongoDB==========================
// producation config or local config
var dbString = "mongodb://localhost:27017/demoproject";

var options = {
    useNewUrlParser: true,
    useUnifiedTopology: true
};
var db = mongoose.connect(dbString, options, function (err) {
    if (err) {
        console.log(err + "connection failed");
    } else {
        console.log('Connected to database ');
    }
});
//mongo on connection emit
mongoose.connection.on('connected', function (err) {
    console.log("mongo Db conection successfull");
});
//mongo on error emit
mongoose.connection.on('error', function (err) {
    console.log("MongoDB Error: ", err);
});
//mongo on dissconnection emit
mongoose.connection.on('disconnected', function () {
    console.log("mongodb disconnected and trying for reconnect");
    //mongoose.connectToDatabase();
});
//===========================Connect to MongoDB==========================
app.set('port', 1971);
server.listen(app.get('port'), function (err) {
    if (err) {
        throw err;
    }
    else {
        console.log("Server is running at http://localhost:" + app.get('port'));
    }
});
server.timeout = 5000000; 
