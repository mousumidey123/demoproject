'use strict';
var express = require("express");
var apiService = require('../services/apiService');
var bodyParser = require('body-parser');
var TaskModels = require('../models/task');
var async = require("async");
const https = require('http')

module.exports = function (app, express) {

    var api = express.Router();

    api.use(bodyParser.json());
    api.use(bodyParser.urlencoded({
        extended: false
    }));
    //app.use(fileUpload());

    api.post('/createtask', function (req, res) {
        
        apiService.createtask(req.body, function (result) {
            res.send(result)
        });

    });
    //Register
    api.post('/createcategory', function (req, res) {
        console.log("registerregisterregisterregisterregister",req.body);
        apiService.createcategory(req.body, function (result) {
            res.send(result)
        });
    });
    

    // get all banners
    api.post('/getalltask', function (req, res) {
        req.body._id = req.decoded.id;
        apiService.getAllCategories(req.body, function (result) {
            res.send(result)
        })
    });
    

    return api;
}

