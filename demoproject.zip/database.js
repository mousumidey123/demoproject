// const { createConnection } = require('mysql')

// const conn = createConnection({
//     host:'localhost',
//     user:'root',
//     password:'',
//     database: 'test'
// })

// conn.query('insert into test () values ()',(err, result, fields)=>{
//     if(err){
//         return console.log(err)
//     }
//     return console.log(result)
// })

