var TaskSchema = require('../schema/task');
var Categoriesschema = require('../schema/categories');


var TaskModels = {
    
    createtask: function (data, callback) {
        if (data) {
            async.waterfall([
                function (nextCb) {
                        new TaskSchema(data).save(function (err, result) {
                            if (err) {
                                callback({
                                    "response_code": 505,
                                    "response_message": "INTERNAL DB ERROR",
                                    "response_data": err
                                });
                            } else {
                                callback({
                                    "response_code": 200,
                                    "response_message": "Task create successfully.",
                                    "response_data": result
                                });
                            }
                        });
                    
                }
            ], function (err, content) {
                if (err) {
                    callback({
                        "response_code": 505,
                        "response_message": "INTERNAL DB ERROR",
                        "response_data": err
                    });
                } else {
                    callback(content);
                }
            });
        } else {
            callback({
                "response_code": 502,
                "response_message": "Please provide required information.",
                "response_data": {}
            });
        }
    },


    gettask: function (data, callback) {
        if (data) {
            TaskSchema.aggregate([
                {
                    $project: {
                        name: 1,
                        category: 1,
                    }
                },
                {
                    $lookup:
                    {
                        from: "categories",
                        localField: "_id",
                        foreignField: "category",
                        as: "category"
                    }
                },
                {
                    $sort: {
                        timestamp: -1
                    }
                }],
                function (err, result) {
                    if (err) {
                        callback({
                            "response_code": 505,
                            "response_message": "INTERNAL DB ERROR",
                            "response_data": {}
                        })
                    } else {
                        callback({
                            "response_code": 200,
                            "response_message": "List",
                            "response_data": result
                        })
                    }
                });
        } else {
            callback({
                "response_code": 502,
                "response_message": "Please provide required information.",
                "response_data": {}
            });
        }
    },

}

module.exports = TaskModels;