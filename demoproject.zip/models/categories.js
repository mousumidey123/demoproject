var TaskSchema = require('../schema/task');
var Categoriesschema = require('../schema/categories');


var CategoriesModels = {
    
    createcategory: function (data, callback) {
        if (data) {
            async.waterfall([
                function (nextCb) {
                        new Categoriesschema(data).save(function (err, result) {
                            if (err) {
                                callback({
                                    "response_code": 505,
                                    "response_message": "INTERNAL DB ERROR",
                                    "response_data": err
                                });
                            } else {
                                callback({
                                    "response_code": 200,
                                    "response_message": "Category create successfully.",
                                    "response_data": result
                                });
                            }
                        });
                    
                }
            ], function (err, content) {
                if (err) {
                    callback({
                        "response_code": 505,
                        "response_message": "INTERNAL DB ERROR",
                        "response_data": err
                    });
                } else {
                    callback(content);
                }
            });
        } else {
            callback({
                "response_code": 502,
                "response_message": "Please provide required information.",
                "response_data": {}
            });
        }
    },


    

}

module.exports = CategoriesModels;